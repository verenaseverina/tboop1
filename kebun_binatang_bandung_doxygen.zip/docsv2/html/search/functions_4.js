var searchData=
[
  ['incage',['InCage',['../classZoo.html#a99a7385a0459eb61e42956e80a0bd3a2',1,'Zoo']]],
  ['interact',['Interact',['../classAnimal.html#a7303717426fc66292257a75e737822fb',1,'Animal']]],
  ['isempty',['IsEmpty',['../classCage.html#a6fb42abe4cde554e4523f6729d53ec9d',1,'Cage']]],
  ['isfacility',['IsFacility',['../classZoo.html#ae9de75afa868a2830ce2c54f884bde7e',1,'Zoo']]],
  ['isfull',['IsFull',['../classCage.html#a8d618ac503c111741ee84aa09a408f06',1,'Cage']]],
  ['ishabitat',['IsHabitat',['../classZoo.html#a45b4b6d43b1347255fe66c94971aedc2',1,'Zoo']]],
  ['isthereanimal',['IsThereAnimal',['../classRenderable.html#a2b595f03f2b363e4bf45f06526052d28',1,'Renderable']]]
];
