var searchData=
[
  ['set_5ftrue',['set_true',['../classCell.html#af433bb752e3f54b88b86b5f5c1be8fc8',1,'Cell']]],
  ['state',['State',['../classState.html#ab91bb1dd5aa6260ab2a456581daf9ec2',1,'State']]]
];
