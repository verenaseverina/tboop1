var searchData=
[
  ['ostrich',['Ostrich',['../classOstrich.html',1,'']]]
];
