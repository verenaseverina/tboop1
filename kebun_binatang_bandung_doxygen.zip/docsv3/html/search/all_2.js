var searchData=
[
  ['dolphin',['Dolphin',['../classDolphin.html',1,'Dolphin'],['../classDolphin.html#a6a32f0e310f242bc98dbfb5a100d883c',1,'Dolphin::Dolphin()']]]
];
