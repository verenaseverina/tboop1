var searchData=
[
  ['elangb',['ElangB',['../classElangB.html',1,'ElangB'],['../classElangB.html#a773057746057ea29f83840347596a6d1',1,'ElangB::ElangB()']]]
];
